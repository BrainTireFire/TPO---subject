module zad1.tpo3_km_s20202 {
    requires javafx.controls;
    requires javafx.fxml;


    opens zad1.tpo3_km_s20202 to javafx.fxml;
    exports zad1.tpo3_km_s20202;
}